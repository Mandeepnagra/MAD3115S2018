//
//  ZodiacDetailVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ZodiacDetailVC: UIViewController {

    @IBOutlet weak var lblColor: UILabel!
    @IBOutlet weak var lblBirthStone: UILabel!
    @IBOutlet weak var lblZodiac: UILabel!
    var selectedZodiac: Int?
    var plistArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if selectedZodiac != nil{
            fetchZodiacDetails()
            displayValues()
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func displayValues(){
        lblZodiac.text = ZodiacItems.zodiac[self.selectedZodiac!]
        let zodiacdetails = plistArray[self.selectedZodiac!] as! NSMutableDictionary
        
        //lblColor.text = ZodiacItems.zodiacColors[self.selectedZodiac!]
        //lblBirthStone.text = ZodiacItems.zodiacBirthStone[self.selectedZodiac!]
        
        self.lblColor.text = zodiacdetails.value(forKey: "Color")  as? String
        
        self.lblBirthStone.text = zodiacdetails.value(forKey: "BirthStone") as? String
        
        
    }
    
    func fetchZodiacDetails(){
        if let filePath = Bundle.main.path(forResource: "Zodiac", ofType: "plist"){
            plistArray = NSMutableArray(contentsOfFile: filePath)!
            print("pListArray \(plistArray)")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
